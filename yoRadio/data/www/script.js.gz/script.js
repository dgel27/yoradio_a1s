var hostname = window.location.search!=""?window.location.search.substring(1):window.location.hostname;
var websocket;
var wserrcnt = 0;
var wstimeout;
var currentItem = 0;
var speakerMuted = 0;
var hpPollTimer = 0;

window.addEventListener('load', onLoad);

function initWebSocket() {
  clearTimeout(wstimeout);
  console.log('Trying to open a WebSocket connection...');
  websocket = new WebSocket(`ws://${hostname}/ws`);
  websocket.onopen    = onOpen;
  websocket.onclose   = onClose;
  websocket.onmessage = onMessage;
}
function onOpen(event) {
  console.log('Connection opened');
  wserrcnt=0;
  websocket.send('getmode=1');
}
function onClose(event) {
  wserrcnt++;
  wstimeout=setTimeout(initWebSocket, wserrcnt<10?2000:120000);
}
function escapeData(data){
  let m=data.match(/{.+?:\s"(.+?)"}/);
  if(m!==null){
    let m1 = m[1];
    if(m1.indexOf('"') !== -1){
      let mq=m1.replace(/["]/g, '\\\"');
      return data.replace(m1,mq);
    }
  }
  return data;
}
function quoteattr(s) {
  return ('' + s)
    .replace(/&/g, '&amp;')
    .replace(/'/g, '&apos;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;');
}
function secondToTime(seconds){
  if(seconds>=3600){
    return new Date(seconds * 1000).toISOString().substring(11, 19);
  }else{
    return new Date(seconds * 1000).toISOString().substring(14, 19);
  }
}
function onMessage(event) {
  var data = JSON.parse(escapeData(event.data));
  if(typeof data.pmode !== 'undefined'){
    if(data.pmode=="player"){
      if(window.location.pathname.includes("settings")){
        websocket.send('getsystem=1');
        websocket.send('getscreen=1');
        websocket.send('gettimezone=1');
        websocket.send('getweather=1');
        websocket.send('getcontrols=1');
        websocket.send('getes8388=1');
        websocket.send('getmqtt=1');
        startHpPoll();
        getWiFi(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime());
        websocket.send('getactive=1');
      }else if(window.location.pathname.includes("index") || window.location.pathname=="/"){
        websocket.send('getindex=1');
        // the main screen shows the ES8388 speaker balance, stereo width and
        // the speaker mute button, so it needs those values too
        websocket.send('getes8388=1');
        generatePlaylist(`http://${hostname}/data/playlist.csv`+"?"+new Date().getTime());
      }
    }else{
      getWiFi(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime());
      websocket.send('getactive=1');
    }
    return;
  }
  if(typeof data.mqhost !== 'undefined'){
    document.getElementById("mqtthost").value=data.mqhost;
    document.getElementById("mqttport").value=data.mqport;
    document.getElementById("mqtttopic").value=data.mqtopic;
    document.getElementById("mqttuser").value=data.mquser;
    // The device sends the stored password back so the field can be shown, but it
    // is never echoed to the terminal and the input is type=password.
    document.getElementById("mqttpass").value=data.mqpass;
    document.getElementById("mqttstatus").innerText = data.mqen?"enabled":"disabled (no host)";
    return;
  }
  if(typeof data.esmv !== 'undefined'){
    setSlRangeValue(document.getElementById("es_vol1"),data.esv1);
    setSlRangeValue(document.getElementById("es_ch1bal"),data.esb1);
    setSlRangeValue(document.getElementById("es_vol2"),data.esv2);
    setSlRangeValue(document.getElementById("es_ch2bal"),data.esb2);
    setSlRangeValue(document.getElementById("es_stereo"),data.esse);
    setSlRangeValue(document.getElementById("es_vpp"),data.esvpp);
    setSlRangeValue(document.getElementById("es_deemph"),data.esde);
    setSlRangeValue(document.getElementById("es_micpga"),data.espg);
    setSlRangeValue(document.getElementById("es_micin"),data.esmi);
    checkSelectSet("hpmutesp",data.esmu);
    checkSelectSet("esmute2",data.esmu2);
    // the settings checkbox and the main-screen button share one state
    speakerMuted = data.esmu==1 ? 1 : 0;
    setMuteButton(speakerMuted);
    checkSelectSet("esmono",data.esmo);
    checkSelectSet("esramp",data.esra);
    checkSelectSet("esvroi",data.esvr);
    // eslinein is a 0/1/2 slider (off / mix / line only), not a checkbox, so it
    // goes through setSlRangeValue; the slider's data-slavelabels turns the
    // number into the word. eslg is its gain in dB.
    setSlRangeValue(document.getElementById("es_linein"),data.esli);
    setSlRangeValue(document.getElementById("es_lingain"),data.eslg);
    checkSelectSet("esadc",data.esad);
    checkSelectSet("esmicbias",data.esmb);
    checkSelectSet("esstandby",data.essb);
    return;
  }
  // Standalone jack state. Handled separately from the es8388 block above on
  // purpose: this is polled, and re-applying every slider on each tick would
  // fight the user if they were dragging esvol2 at the time.
  if(typeof data.esatt !== 'undefined'){
    setHpAttached(data.esatt);
    return;
  }
  if(typeof data.sst !== 'undefined'){
    checkSelectSet("smartstart",data.sst);
    checkSelectSet("audioinfo",data.aif);
    checkSelectSet("vumeter",data.vu);
    setSlRangeValue(document.getElementById("slsoftap"),data.softr);
    if(typeof data.mdns !== 'undefined') document.getElementById("mdnsname").value=data.mdns;
    return;
  }
  if(typeof data.flip !== 'undefined'){
    checkSelectSet("flipscreen",data.flip);
    checkSelectSet("invertdisplay",data.inv);
    checkSelectSet("numplaylist",data.nump);
    checkSelectSet("fliptouch",data.tsf);
    checkSelectSet("dbgtouch",data.tsd);
    checkSelectSet("screenon",data.dspon);
    setSlRangeValue(document.getElementById("slbrightness"),data.br);
    setSlRangeValue(document.getElementById("slcontrast"),data.con);
    if(typeof data.scre !== 'undefined') checkSelectSet("screensaverenabled",data.scre);
    if(typeof data.scrt !== 'undefined') document.getElementById("screensavertimeout").value=data.scrt;
    if(typeof data.scrb !== 'undefined') checkSelectSet("screensaverblank",data.scrb);
    if(typeof data.scrpe !== 'undefined') checkSelectSet("screensaverplayingenabled",data.scrpe);
    if(typeof data.scrpt !== 'undefined') document.getElementById("screensaverplayingtimeout").value=data.scrpt;
    if(typeof data.scrpb !== 'undefined') checkSelectSet("screensaverplayingblank",data.scrpb);
    return;
  }
  if(typeof data.redirect !== 'undefined'){
    document.getElementById("mdnsnamerow").innerHTML=`<h3 style="line-height: 37px;color: #aaa; margin: 0 auto;">redirecting to ${data.redirect}</h3>`;
    setTimeout(function(){ window.location.href=data.redirect; }, 4000);
    return;
  }
  if(typeof data.dspontrue !== 'undefined'){
    checkSelectSet("screenon",data.dspontrue);
    return;
  }
  if(typeof data.tzh !== 'undefined'){
    document.getElementById("tzhour").value=data.tzh;
    document.getElementById("tzmin").value=data.tzm;
    document.getElementById("sntp2").value=data.sntp2;
    document.getElementById("sntp1").value=data.sntp1;
    return;
  }
  if(typeof data.wen !== 'undefined'){
    checkSelectSet("showweather",data.wen);
    document.getElementById("weatherlat").value=data.wlat;
    document.getElementById("weatherlon").value=data.wlon;
    document.getElementById("weatherkey").value=data.wkey;
    return;
  }
  if(typeof data.sdpos !== 'undefined'){
    //setSlRangeValue(document.getElementById("sdpos"),data.sdpos);
    if(data.sdtpos==0 && data.sdtend==0){
      document.getElementById("sdposvalscurrent").innerHTML="00:00";
      document.getElementById("sdposvalsend").innerHTML="00:00";
      setSlRangeValue(document.getElementById("sdpos"),0);
    }else{
      document.getElementById("sdposvalscurrent").innerHTML=secondToTime(data.sdtpos);
      document.getElementById("sdposvalsend").innerHTML=secondToTime(data.sdtend);
      setSlRangeValue(document.getElementById("sdpos"),data.sdpos);
    }
    return;
  }
  if(typeof data.sdmin !== 'undefined'){
    document.getElementById("sdpos").setAttribute('min',data.sdmin); 
    document.getElementById("sdpos").setAttribute('max',data.sdmax); 
    return;
  }
  if(typeof data.snuffle!== 'undefined'){
    if(data.snuffle==1){
      document.getElementById("snuffle").classList.add("active");
    }else{
      document.getElementById("snuffle").classList.remove("active");
    }
    return;
  }
  
  if(typeof data.vols !== 'undefined'){
    setSlRangeValue(document.getElementById("slvolsteps"),data.vols);
    setSlRangeValue(document.getElementById("slencacceleration"),data.enca);
    setSlRangeValue(document.getElementById("slirtlp"),data.irtl);
    if(typeof data.skipup !== 'undefined') checkSelectSet("oneclickswitching",data.skipup);
    return;
  }
  if(typeof data.act !== 'undefined'){
    let group = document.getElementsByClassName("group");
    for (var i = 0; i <= group.length - 1; i++) {
      for (let j = 0; j <= data.act.length-1; j++) {
        if(group[i].classList.contains(data.act[j])){
          group[i].classList.remove("hidden");
          break;
        }
      }
    }
    return;
  }
  if(document.getElementById('meta')){ // index loaded
    if(typeof data.nameset !== 'undefined') { document.getElementById('nameset').innerHTML = data.nameset; return; }
    if(typeof data.meta !== 'undefined') { document.getElementById('meta').innerHTML = data.meta; return; }
    if(typeof data.vol !== 'undefined') {
      setSlRangeValue(document.getElementById('volrange'),data.vol);
      return;
    }
    if(typeof data.current !== 'undefined') { setCurrentItem(data.current); return; }
    if(typeof data.file !== 'undefined') {  generatePlaylist(data.file+"?"+new Date().getTime()); websocket.send('submitplaylistdone=1'); return; }
    if(typeof data.bitrate !== 'undefined') { 
          let fmt=typeof data.format !== 'undefined'?data.format:'bitrate';
          document.getElementById('bitinfo').innerText = fmt+': '+data.bitrate+'kBits'; 
          return; 
        }
    if(typeof data.rssi !== 'undefined') {
      let rsiinfo=document.getElementById('rsiinfo');
      if(rsiinfo) rsiinfo.innerText = 'rssi: '+data.rssi+'dBm';
      return;
    }
    if(typeof data.mode !== 'undefined') { document.getElementById('playbutton').setAttribute("class",data.mode); return; }
    if(typeof data.bass !== 'undefined') {
    	setSlRangeValue(document.getElementById('eqbass'),data.bass);
    	setSlRangeValue(document.getElementById('eqmiddle'),data.middle);
    	setSlRangeValue(document.getElementById('eqtreble'),data.trebble);
    	return;
    }
    if(typeof data.balance !== 'undefined') {
      // SW balance no longer has a slider on the main screen (HW speaker
      // balance moved there instead), but still consume the reply so it does
      // not fall through to the handlers below.
      return;
    }
    if(typeof data.playermode !== 'undefined') { //Web, SD
      document.getElementById('sdnav').classList.add('hidden');
      document.getElementById('volnav').classList.remove('hidden');
      document.getElementById('sdbutton').classList.remove('active');
      let elements = document.getElementsByClassName("modeitem");
      for (var i = 0; i < elements.length; i++) {
        elements[i].classList.remove('active');
      }
      document.getElementById(data.playermode).classList.add('active');
      document.body.setAttribute("class", data.playermode);
    }
    if(typeof data.sdinit !== 'undefined') {
      if(data.sdinit==1) {
        document.getElementById('equalizerwrap').classList.add("sd");
        document.getElementsByClassName('playerbyttonwrap')[0].classList.add("sd");
      }else{
        document.getElementById('equalizerwrap').classList.remove("sd");
        document.getElementsByClassName('playerbyttonwrap')[0].classList.remove("sd");
      }
    }
  }
}
function handleWiFiData(fileData) {
  if (!fileData) return;
  var lines = fileData.split('\n');
  for(var i = 0;i < lines.length;i++){
    let line = lines[i].split('\t');
    if(line.length==2){
      document.getElementById("ssid"+i).value=line[0].trim();
      document.getElementById("pass"+i).setAttribute('data-pass', line[1].trim());
    }
  }
}
function getWiFi(path){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        handleWiFiData(xhr.responseText);
      } else {
        handleWiFiData(null);
      }
    }
  };
  xhr.open("GET", path);
  xhr.send(null);
}
function submitWiFi(){
  var items=document.getElementsByClassName("credential");
  var output="";
  for (var i = 0; i <= items.length - 1; i++) {
    inputs=items[i].getElementsByTagName("input");
    if(inputs[0].value == "") continue;
    let ps=inputs[1].value==""?inputs[1].getAttribute('data-pass'):inputs[1].value;
    output+=inputs[0].value+"\t"+ps+"\n";
  }
  if(output!=""){ // Well, let's say, quack.
    let file = new File([output], "tempwifi.csv",{type:"text/plain;charset=utf-8", lastModified:new Date().getTime()});
    let container = new DataTransfer();
    container.items.add(file);
    let fileuploadinput=document.getElementById("file-upload");
    fileuploadinput.files = container.files;
    var formData = new FormData();
	  formData.append("wifile", fileuploadinput.files[0]);
	  var xhr = new XMLHttpRequest();
	  xhr.open("POST",`http://${hostname}/upload`,true);
	  xhr.send(formData);
	  fileuploadinput.value = '';
	  document.getElementById("settingscontent").innerHTML="<h2>Settings saved. Rebooting...</h2>";
	  document.getElementById("settingsdone").classList.add("hidden");
	  document.getElementById("navigation").classList.add("hidden");
	  setTimeout(function(){ window.location.href=`http://${hostname}/`; }, 10000);
  }
}
function scrollToCurrent(){
  var pl = document.getElementById('playlist');
  var lis = pl.getElementsByTagName('li');
  var plh = pl.offsetHeight;
  var plt = pl.offsetTop;
  var topPos = 0;
  var lih = 0;
  for (var i = 0; i <= lis.length - 1; i++) {
    if(i+1==currentItem) {
      topPos = lis[i].offsetTop;
      lih = lis[i].offsetHeight;
    }
  }
  pl.scrollTo({
    top: topPos-plt-plh/2+lih/2,
    left: 0,
    behavior: 'smooth'
  });
}
function setCurrentItem(item){
  currentItem=item;
  var pl = document.getElementById('playlist');
  var lis = pl.getElementsByTagName('li');
  for (var i = 0; i <= lis.length - 1; i++) {
    lis[i].removeAttribute('class');
    if(i+1==currentItem) {
      lis[i].setAttribute("class","active");
    }
  }
  scrollToCurrent();
}
function playStation(el){
  let lis = document.getElementById('playlist').getElementsByTagName('li');
  for (let i = 0; i <= lis.length - 1; i++) {
    lis[i].removeAttribute('class');
  }
  el.setAttribute("class","active");
  id=el.getAttribute('attr-id');
	xhr = new XMLHttpRequest();
	xhr.open("POST",`http://${hostname}/`,true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send("playstation="+id);
}
function handlePlaylistData(fileData) {
  if (!fileData) return;
  var lines = fileData.split('\n');
  var ul = document.getElementById('playlist');
  ul.innerHTML="";
  for(var i = 0;i < lines.length;i++){
    let line = lines[i].split('\t');
    if(line.length==3){
      li = document.createElement('li');
      li.setAttribute('onclick','playStation(this);');
      li.setAttribute('attr-id', i+1);
      li.setAttribute('attr-name', line[0].trim());
      li.setAttribute('attr-url', line[1].trim());
      li.setAttribute('attr-ovol', line[2].trim());
      if(i+1==currentItem){
        li.setAttribute("class","active");
      }
      var span = document.createElement('span');
      span.innerHTML = i+1;
      li.appendChild(document.createTextNode(line[0].trim()));
      li.appendChild(span);
      ul.appendChild(li);
    }
  }
  initPLEditor();
  scrollToCurrent();
}
function generatePlaylist(path){
  var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4) {
      if (xhr.status == 200) {
        handlePlaylistData(xhr.responseText);
      } else {
        handlePlaylistData(null);
      }
    }
  };
  xhr.open("GET", path);
  xhr.send(null);
}
// Repaints the main-screen mute button. speakerMuted is the shared state for
// the settings checkbox and this button; hpmutesp pushes nothing back.
function setMuteButton(muted){
  let mb = document.getElementById("mutebutton");
  if(mb) mb.classList.toggle("muting", muted==1);
}
/* Poll the jack while the settings page is open so plugging headphones in
   un-greys the controls without a reload. Deliberately a separate command from
   getes8388: that reply re-applies every slider value, so polling it would fight
   the user whenever they were mid-drag on esvol2. 2s is immediate enough to feel
   like a reaction and infrequent enough not to show up on the websocket. */
function startHpPoll(){
  if(hpPollTimer) return;          // only ever one timer, however often init runs
  websocket.send('gethp=1');
  hpPollTimer = setInterval(function(){ websocket.send('gethp=1'); }, 2000);
}
/* Grey out the headphone-amp controls while nothing is plugged in. The settings
   are still stored and still come back when a headphone is inserted, so this is
   purely about not offering a control that cannot currently do anything. */
function setHpAttached(att){
  let els=[document.getElementById("esmute2"),
           document.getElementById("es_vol2"),
           document.getElementById("es_ch2bal")];
  let on = att==1;
  els.forEach(function(el){
    if(el) el.classList.toggle("disabled", !on);
  });
  let info=document.getElementById("hpstateinfo");
  if(info) info.innerText = on ? "" : "no headphone detected";
}
function checkSelectSet(name, val){
  let checkb=document.getElementById(name);
  if(!checkb) return;
  checkb.classList.remove("on");
  checkb.classList.remove("off");
  checkb.classList.add(val==1?"on":"off");
}
function applyTZ(){
  websocket.send("tzh="+document.getElementById("tzhour").value);
  websocket.send("tzm="+document.getElementById("tzmin").value);
  websocket.send("sntp2="+document.getElementById("sntp2").value);
  websocket.send("sntp1="+document.getElementById("sntp1").value);
}
function checkSelect(){
  // Ignore clicks on a greyed-out control. The click handler is attached to the
  // element once at load, so removing pointer-events in CSS is not enough on its
  // own for every browser; checking here as well keeps a stray tap from storing
  // a setting the UI is currently telling the user is inactive.
  if(this.classList.contains("disabled")) return;
  var checked = this.classList.contains("on");
  let newval;
  if(checked){
    this.classList.remove("on");
    this.classList.add("off");
    newval=0;
  }else{
    this.classList.remove("off");
    this.classList.add("on");
    newval=1;
  }
  websocket.send(this.getAttribute('id')+"="+newval);
}
function initPLEditor(){
  ple= document.getElementById('pleditorcontent');
  ple.innerHTML="";
  pllines = document.getElementById('playlist').getElementsByTagName('li');
  for (let i = 0; i <= pllines.length - 1; i++) {
    plitem = document.createElement('li');
    plitem.setAttribute('class', 'pleitem');
    plitem.setAttribute('id', 'plitem'+i);
    let pName = pllines[i].getAttribute('attr-name');
    let pUrl = pllines[i].getAttribute('attr-url');
    let pOvol = pllines[i].getAttribute('attr-ovol');
    plitem.innerHTML = '<span class="grabbable" draggable="true">'+("00"+(i+1)).slice(-3)+'</span>\
          <span class="pleinput plecheck"><input type="checkbox" class="plcb" /></span>\
          <input class="pleinput plename" type="text" value="'+quoteattr(pName)+'" maxlength="140" />\
          <input class="pleinput pleurl" type="text" value="'+pUrl+'" maxlength="140" />\
          <input class="pleinput pleovol" type="number" min="-64" max="64" step="1" value="'+pOvol+'" />';
    ple.appendChild(plitem);
  }
}
function showEqualizer(){
	document.getElementById('equalizerbg').classList.toggle('hidden');
}
function selectAll(el){
  var cbxs = document.getElementsByClassName('plcb');
	for (var i = 0; i <= cbxs.length - 1; i++) {
		cbxs[i].checked = el.checked;
	}
}
function doPlUpload(finput) {
  websocket.send("submitplaylist=1");
  var formData = new FormData();
	formData.append("plfile", finput.files[0]);
	var xhr = new XMLHttpRequest();
	xhr.open("POST",`http://${hostname}/upload`,true);
	xhr.send(formData);
	finput.value = '';
}
function plAddStation(pName, pUrl){
  let ple=document.getElementById('pleditorcontent');
  let cnt=ple.getElementsByTagName('li');
  let plitem=document.createElement('li');
  plitem.setAttribute('class','pleitem');
  plitem.setAttribute('id','plitem'+cnt.length);
  let num=document.createElement('span');
  num.setAttribute('class','grabbable');
  num.setAttribute('draggable','true');
  num.innerText=("00"+(cnt.length+1)).slice(-3);
  let chkwrap=document.createElement('span');
  chkwrap.setAttribute('class','pleinput plecheck');
  let cb=document.createElement('input');
  cb.setAttribute('type','checkbox');
  cb.setAttribute('class','plcb');
  chkwrap.appendChild(cb);
  let nm=document.createElement('input');
  nm.setAttribute('class','pleinput plename');
  nm.setAttribute('type','text');
  nm.setAttribute('maxlength','140');
  nm.value=pName;
  let ur=document.createElement('input');
  ur.setAttribute('class','pleinput pleurl');
  ur.setAttribute('type','text');
  ur.setAttribute('maxlength','140');
  ur.value=pUrl;
  let ov=document.createElement('input');
  ov.setAttribute('class','pleinput pleovol');
  ov.setAttribute('type','number');
  ov.setAttribute('min','-30');
  ov.setAttribute('max','30');
  ov.setAttribute('step','1');
  ov.value="0";
  plitem.appendChild(num);
  plitem.appendChild(chkwrap);
  plitem.appendChild(nm);
  plitem.appendChild(ur);
  plitem.appendChild(ov);
  ple.appendChild(plitem);
  ple.scrollTo({
		top: ple.scrollHeight,
		left: 0,
		behavior: 'smooth'
  });
}
function plAdd(){
  plAddStation("","");
}
var plPreviewAudio=null;
var plPreviewBtn=null;
function plPreviewStop(){
  if(plPreviewAudio){plPreviewAudio.pause();plPreviewAudio.removeAttribute('src');plPreviewAudio.load();plPreviewAudio=null;}
  if(plPreviewBtn){plPreviewBtn.innerText="Preview";plPreviewBtn=null;}
}
function plPreview(url,btn){
  if(plPreviewBtn===btn){plPreviewStop();return;}
  plPreviewStop();
  plPreviewAudio=new Audio(url);
  plPreviewBtn=btn;
  btn.innerText="Stop";
  var started=plPreviewAudio.play();
  if(started&&typeof started.catch==='function'){started.catch(function(){plPreviewStop();});}
  plPreviewAudio.onerror=function(){plPreviewStop();};
  plPreviewAudio.onended=function(){plPreviewStop();};
}
function plPlayDevice(url){
  var xhr=new XMLHttpRequest();
  xhr.open("POST",`http://${hostname}/`,true);
  xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
  xhr.send("burl="+encodeURIComponent(url));
}
function plSearch(){
  let q=document.getElementById('plsearch').value.trim();
  let box=document.getElementById('plsearchresults');
  if(q==""){box.innerHTML="";return;}
  box.innerHTML="Searching...";
  fetch("https://de1.api.radio-browser.info/json/stations/search?name="+encodeURIComponent(q)+"&hidebroken=true&order=votes&reverse=true&limit=30")
    .then(function(r){if(!r.ok)throw 0;return r.json();})
    .then(function(list){
      box.innerHTML="";
      if(!list.length){box.innerHTML="Nothing found.";return;}
      list.forEach(function(st){
        let url=st.url_resolved||st.url;
        if(!url)return;
        let name=st.name||url;
        let row=document.createElement('div');
        row.setAttribute('class','plsr');
        let t=document.createElement('span');
        t.innerText=name+" ["+(st.countrycode||"--")+"]"+(st.bitrate?" "+st.bitrate+"k":"");
        t.setAttribute('title',url);
        let pd=document.createElement('div');
        pd.setAttribute('class','button');
        pd.innerText="Play";
        pd.setAttribute('title','Play on device');
        pd.onclick=function(){plPlayDevice(url);};
        let pv=document.createElement('div');
        pv.setAttribute('class','button');
        pv.innerText="Preview";
        pv.setAttribute('title','Preview in browser');
        pv.onclick=function(){plPreview(url,pv);};
        let b=document.createElement('div');
        b.setAttribute('class','button');
        b.innerText="Add";
        b.onclick=function(){plAddStation(name,url);};
        row.appendChild(t);
        row.appendChild(pd);
        row.appendChild(pv);
        row.appendChild(b);
        box.appendChild(row);
      });
    })
    .catch(function(){box.innerHTML="Search failed. Check internet connection.";});
}
function plRemove(){
	let items=document.getElementById('pleditorcontent').getElementsByTagName('li');
	let pass=[];
	for (let i = 0; i <= items.length - 1; i++) {
		if(items[i].getElementsByTagName('span')[1].getElementsByTagName('input')[0].checked) {
			pass.push(items[i]);
		}
	}
	if(pass.length==0) {
		alert('Choose something first');
		return;
	}
	for (var i = 0; i < pass.length; i++)
	{
		pass[i].remove();
	}
	items=document.getElementById('pleditorcontent').getElementsByTagName('li');
	for (let i = 0; i <= items.length-1; i++) {
		items[i].getElementsByTagName('span')[0].innerText=("00"+(i+1)).slice(-3);
	}
}
function submitPlaylist(){
  var items=document.getElementById("pleditorcontent").getElementsByTagName("li");
  var output="";
  for (var i = 0; i <= items.length - 1; i++) {
    inputs=items[i].getElementsByTagName("input");
    if(inputs[1].value == "" || inputs[2].value == "") continue;
    let ovol = inputs[3].value;
    if(ovol < -30) ovol = -30;
    if(ovol > 30) ovol = 30;
    output+=inputs[1].value+"\t"+inputs[2].value+"\t"+inputs[3].value+"\n";
  }
  let file = new File([output], "tempplaylist.csv",{type:"text/plain;charset=utf-8", lastModified:new Date().getTime()});
  let container = new DataTransfer();
  container.items.add(file);
  let fileuploadinput=document.getElementById("file-upload");
  fileuploadinput.files = container.files;
  doPlUpload(fileuploadinput);
  document.getElementById('pleditorwrap').classList.toggle('hidden');
}
function showEditor(){
  document.getElementById('equalizerbg').setAttribute('class','hidden');
  initPLEditor();
  document.getElementById('pleditorwrap').classList.toggle('hidden');
}
function playercommand(cmd){
	xhr = new XMLHttpRequest();
	xhr.open("POST",`http://${hostname}/`,true);
	xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhr.send(cmd+"=1");
}
function playbutton(){
  var btn=document.getElementById('playbutton');
	if(btn.getAttribute("class")=="stopped") {
	  btn.setAttribute("class", "playing");
	  playercommand("start");
	  return;
	}
	if(btn.getAttribute("class")=="playing") {
	  btn.setAttribute("class", "stopped");
	  playercommand("stop");
	}
}
function changeMode(){
  if(this.classList.contains('active')) return;
  this.classList.add('active');
  websocket.send("newmode="+(this.getAttribute('data-name')=="web"?0:1));
}
function buttonClick(){
  let target=this.getAttribute('data-name');
  switch (target) {
    case "applyweather":
      let key=document.getElementById("weatherkey").value;
      if(key!=""){
        websocket.send("lat="+document.getElementById("weatherlat").value);
        websocket.send("lon="+document.getElementById("weatherlon").value);
        websocket.send("key="+key);
      }
      break;
    case "rebootmdns": websocket.send("rebootmdns="); break;
    case "fwupdate": window.location.href=`http://${hostname}/update`; break;
    case "wifiexport": window.open(`http://${hostname}/data/wifi.csv`+"?"+new Date().getTime()); break;
    case "wifiupload": submitWiFi(); break;
    case "setupir": window.location.href=`http://${hostname}/ir`; break;
    case "settingsdone": window.location.href=`http://${hostname}/`; break;
    case "resetall":
      // Full factory reset. config.reset() re-seeds the EEPROM with the current
      // layout stamp, which is what you want after changing config_t. It does
      // not touch SPIFFS, so the saved networks and playlist stay put.
      if (confirm("Restore factory settings?\n\nEvery saved setting on the radio will be cleared and it will reboot.\nYour WiFi networks and playlist are kept.")) {
        let rx = new XMLHttpRequest();
        rx.open("POST", `http://${hostname}/`, true);
        rx.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        rx.send("reset=1");
      }
      break;
    case "equalizer": showEqualizer(); break;
    case "playlist": showEditor(); break;
    case "settings": window.location.href=`http://${hostname}/settings`; break;
    case "prev": case "next": case "volp": case "volm": playercommand(target); break;
    case "hpmutesp": {
      // The hpmutesp handler does not push state back, so the button keeps
      // the value itself. Flip it on click and redraw, otherwise the second
      // click would read a stale state and mute again instead of unmuting.
      speakerMuted = speakerMuted ? 0 : 1;
      setMuteButton(speakerMuted);
      websocket.send("hpmutesp=" + speakerMuted);
      break;
    }
    case "play": playbutton(); break;
    case "plexport": window.open(`http://${hostname}/data/playlist.csv`); break;
    case "pladd": plAdd(); break;
    case "plsearchbtn": plSearch(); break;
    case "pldel": plRemove(); break;
    case "plsubmit": submitPlaylist(); break;
    case "sdcard": toggleSDCard(); break;
    case "snuffle": toggleSnuffle(); break;
    case "webboard": window.location.href=`http://${hostname}/webboard`; break;
    default: break;
  }
}
function toggleSnuffle(){
  document.getElementById('snuffle').classList.toggle('active');
  websocket.send("snuffle="+document.getElementById("snuffle").classList.contains('active'));
}
function toggleSDCard(){
  let sdbutton = document.getElementById('sdbutton');
  sdbutton.classList.toggle('active');
  if(sdbutton.classList.contains('active')){
    document.getElementById('sdnav').classList.remove('hidden');
    document.getElementById('volnav').classList.add('hidden');
  }else{
    document.getElementById('sdnav').classList.add('hidden');
    document.getElementById('volnav').classList.remove('hidden');
  }
}
function resetClick(){
  websocket.send("reset="+this.getAttribute('data-name'));
}
function navitemClick(){
  document.getElementById(this.getAttribute('data-target')).scrollIntoView({
      behavior: 'smooth'
  });
}
function onSlRangeChange(){
  websocket.send(this.name+"="+this.value);
}
// A slider with data-slavelabels="a,b,c" shows the matching word instead of the
// raw index, which is what a discrete mode selector needs - "line only" reads
// better than "2" and stays unambiguous after the user drags it. Sliders without
// the attribute are untouched and keep showing their number.
function slLabel(el){
  let labels=el.getAttribute('data-slavelabels');
  if(labels===null) return null;
  let v=labels.split(',')[parseInt(el.value,10)];
  return v===undefined ? el.value : v;
}
function setSlRangeValue(el, val=null){
  // The main screen and the settings page share this reply but do not have the
  // same controls on it, so the element is not always present.
  if(!el) return;
	let slave = el.getAttribute('data-slaveid');
  if(val!==null){
    el.value = val;
    if(slave!==null) document.getElementById(slave).innerText=slLabel(el);
  }
  if(slave!==null) document.getElementById(slave).innerText=slLabel(el);
  var value = (el.value-el.min)/(el.max-el.min)*100;
  el.style.background = 'linear-gradient(to right, #bfa73e 0%, #bfa73e ' + value + '%, #272727 ' + value + '%, #272727 100%)';
}
function initSliders(){
	var sliders = document.getElementsByClassName('slider');
	for (var i = 0; i <= sliders.length - 1; i++) {
		sliders[i].oninput = function() {
		  setSlRangeValue(this);
		};
		sliders[i].addEventListener('change', onSlRangeChange, false);
		setSlRangeValue(sliders[i], 0);
	}
	let sltemp = document.getElementById("volrange");
	if(sltemp) sltemp.addEventListener("wheel", function(e){
    if (e.deltaY < 0){
      this.valueAsNumber += 1;
    }else{
      this.value -= 1;
    }
    websocket.send('volume='+this.value);
    e.preventDefault();
    e.stopPropagation();
  }, {passive: false});
  
  let elements = document.getElementsByClassName("inputchange");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('input', onSlRangeChange, false);
  }
}
function onMqttField(){
  websocket.send(this.getAttribute('name')+"="+this.value);
}
function initMqttFields(){
  let ids = ["mqtthost","mqttport","mqtttopic","mqttuser","mqttpass"];
  for (var i = 0; i < ids.length; i++) {
    let el = document.getElementById(ids[i]);
    if(el) el.addEventListener('change', onMqttField, false);
  }
}
function initCheckboxes(){
  let elements = document.getElementsByClassName("checkbox");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', checkSelect, false);
  }
}
function initButtons(){
  let elements = document.getElementsByClassName("button");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', buttonClick, false);
  }
  elements = document.getElementsByClassName("playerbytton");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', buttonClick, false);
  }
  elements = document.getElementsByClassName("modeitem");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', changeMode, false);
  }
  elements = document.getElementsByClassName("reset");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', resetClick, false);
    elements[i].setAttribute("title", "reset "+elements[i].getAttribute('data-name')+" values");
  }
  elements = document.getElementsByClassName("navitem");
  for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', navitemClick, false);
  }
  let applytz = document.getElementById("applytz");
  if(applytz) applytz.addEventListener('click', applyTZ, false);
}
function onLoad(event) {
  initCheckboxes();
  initSliders();
  initButtons();
  initMqttFields();
  initWebSocket();
  showOwnBuild();
}
/* The footer already shows YOVERSION, which the build script stamps with the
   firmware commit and the filesystem hash it was compiled against. That fs part
   describes what the firmware EXPECTED. data/www/version.json travels inside
   the SPIFFS image and records what was actually flashed, so if the two ever
   disagree -- an old filesystem left on the device, or a filesystem uploaded
   after the firmware -- this reports the real one. Missing or unreadable is
   normal on a filesystem built before this existed, so it must stay silent. */
function showOwnBuild(){
  fetch('version.json?' + Date.now())
    .then(function(r){ return r.ok ? r.json() : null; })
    .then(function(v){
      if (!v || !v.fs) return;
      let el = document.getElementById('copy');
      if (!el) return;
      let stamp = document.createElement('span');
      stamp.title = 'firmware ' + (v.fw || '?') + ' | filesystem ' + v.fs;
      stamp.textContent = ' [fs:' + v.fs + (v.dirty ? '*' : '') + ']';
      el.appendChild(stamp);
    })
    .catch(function(){ /* no version.json in this filesystem */ });
}
/** UPDATE **/
var uploadWithError = false;
function doUpdate(el) {
  let binfile = document.getElementById('binfile').files[0];
  if(binfile){
    document.getElementById('updateform').setAttribute('class','hidden');
    document.getElementById("updateprogress").value = 0;
    document.getElementById('updateprogress').hidden=false;

    document.getElementById('update_cancel_button').hidden=true;
    var formData = new FormData();
    formData.append("updatetarget", document.getElementById('uploadtype1').checked?"firmware":"spiffs");
	  formData.append("update", binfile);
	  var xhr = new XMLHttpRequest();
	  uploadWithError = false;
	  xhr.onreadystatechange = function() {
      if (xhr.readyState == XMLHttpRequest.DONE) {
        if(xhr.responseText!="OK"){
          document.getElementById("uploadstatus").innerHTML = xhr.responseText;
          uploadWithError=true;
        }
      }
    }
	  xhr.upload.addEventListener("progress", progressHandler, false);
    xhr.addEventListener("load", completeHandler, false);
    xhr.addEventListener("error", errorHandler, false);
    xhr.addEventListener("abort", abortHandler, false);
	  xhr.open("POST",`http://${hostname}/update`,true);
	  xhr.send(formData);
	}else{
	  alert('Choose something first');
	}
}
function progressHandler(event) {
  var percent = (event.loaded / event.total) * 100;
  document.getElementById("uploadstatus").innerHTML = Math.round(percent) + "%&nbsp;&nbsp;uploaded&nbsp;&nbsp;|&nbsp;&nbsp;please wait...";
  document.getElementById("updateprogress").value = Math.round(percent);
  if (percent >= 100) {
    document.getElementById("uploadstatus").innerHTML = "Please wait, writing file to filesystem";
  }
}
var tickcount=0;
function rebootingProgress(){
  document.getElementById("updateprogress").value = Math.round(tickcount/7);
  tickcount+=14;
  if(tickcount>700){
    location.href=`http://${hostname}/`;
  }else{
    setTimeout(rebootingProgress, 200);
  }
}
function completeHandler(event) {
  if(uploadWithError) return;
  document.getElementById("uploadstatus").innerHTML = "Upload Complete, rebooting...";
  rebootingProgress();
}
function errorHandler(event) {
  document.getElementById('updateform').setAttribute('class','');
  document.getElementById('updateprogress').hidden=true;
  document.getElementById("updateprogress").value = 0;
  document.getElementById("status").innerHTML = "Upload Failed";
}
function abortHandler(event) {
  document.getElementById('updateform').setAttribute('class','');
  document.getElementById('updateprogress').hidden=true;
  document.getElementById("updateprogress").value = 0;
  document.getElementById("status").innerHTML = "inUpload Aborted";
}
/** UPDATE **/
